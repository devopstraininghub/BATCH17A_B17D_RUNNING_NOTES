

vpc_cidr = "10.82.0.0/16"
subnet_cidr = "10.82.3.0/24"
eni_pvtip = ["10.82.3.33"]
env_server = "LAB-fb-Server"
server_count = 1
ami = "ami-02dfbd4ff395f2a1b"
instance_type = "t2.micro"  
key_name = "batch17a"
