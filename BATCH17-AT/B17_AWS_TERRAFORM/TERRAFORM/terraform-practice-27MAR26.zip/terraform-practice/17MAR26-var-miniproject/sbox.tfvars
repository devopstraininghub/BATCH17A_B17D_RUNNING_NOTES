

vpc_cidr = "10.83.0.0/16"
subnet_cidr = "10.83.3.0/24"
eni_pvtip = ["10.83.3.33"]
env_server = "SBOX-fb-Server"
count = 1
ami = "ami-02dfbd4ff395f2a1b"
instance_type = "t2.micro"  
key_name = "ramanikey"