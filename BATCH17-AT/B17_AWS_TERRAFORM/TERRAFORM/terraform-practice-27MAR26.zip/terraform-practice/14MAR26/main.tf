

provider "aws" {
  
    region = "us-east-1"
    alias = "nv"

}

provider "aws" {
  
  region = "ap-south-1"
  alias = "mum"

}



# Ec2 Instance in North Virginia

resource "aws_instance" "srv1-nv" {
  ami = "ami-02dfbd4ff395f2a1b"
  instance_type = "t2.micro"
  key_name = "batch17a"

  provider = aws.nv
 
 tags = {
   Name =   "Lab Server-nv" 
 }

  }


  # Ec2 Instance in Mumbai

resource "aws_instance" "srv1-mum" {
  ami = "ami-0f559c3642608c138"
  instance_type = "t2.micro"
  key_name = "b17mumbai"

  provider = aws.mum
 
 tags = {
   Name =   "Lab Server-mum" 
 }

  }