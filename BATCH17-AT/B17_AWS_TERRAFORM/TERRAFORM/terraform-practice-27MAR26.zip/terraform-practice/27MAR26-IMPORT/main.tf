

provider "aws" {
  
  region = "us-east-1"
}

resource "aws_instance" "b17server" {

    ami = "ami-02dfbd4ff395f2a1b"
    instance_type = "t3.micro"
    tags = {
        Name = "prodserver"
    }
  
}


resource "aws_s3_bucket" "b17bucket" {

  bucket = "batch17-test-madhu"

  
}