
terraform {
  backend "s3" {
    bucket         = "b17-state-bucket-12345"
    key            = "batch17/prod/terraform.tfstate"
    region         = "us-east-1"
   # dynamodb_table = "terraform-lock-table"
    use_lockfile = true
    encrypt        = true
  }
}