


provider "aws" {
  region = "us-east-1"
}


resource "aws_instance" "srv" {
  ami           = "ami-02dfbd4ff395f2a1b"
  instance_type = "t3.micro"
  count        = 3

  tags = {
    Name = "B17-EC2-Instance"
  }
  
}

