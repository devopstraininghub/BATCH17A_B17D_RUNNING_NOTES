
ami_id = "ami-0b6c6ebed2801a5cb"
instance_type = "t2.micro"
key_name = "batch17a"
server_env = "SBOX Server "