variable "ami_id" {

 description = "ami-value"  
 default = "ami-02dfbd4ff395f2a1b"
  
}

variable "instance_type" {
  description = "Instance type for the EC2 instance"
  default = "t3.micro"
}

variable "key_name" {
 description = "Key pair name for the EC2 instance"
 default = "ramanikey"

}

variable "server_env" {
  description = "Environment for the server"
  default =  "Lab Instance"
}
